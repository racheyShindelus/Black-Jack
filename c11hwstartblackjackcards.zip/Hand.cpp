#include "Hand.h"

// constructor.
Hand::Hand(std::vector<int> initialCards) {
	int nofInitialCards = initialCards.size();

	// iterate through initial cards and push back into cards.
	for (int i = 0; i < nofInitialCards; i++) {
		//cards.push_back(Card(initialCards[i]));
	}
}

// prints the hand to console.
void Hand::printMe() {
	std::cout << "{ ";

	std::list<Card>::iterator it;
	// iterate through the list and print each card value.
	for (it = cards.begin(); it != cards.end(); ++it) {
		std::cout << *it << ", ";
	}

	std::cout << " }" << std::endl;
}

// returns size of the cards list.
int Hand::size() {
	return cards.size();
}

// take the top element from a hand and return it. 
Card Hand::dealACard() {
	// get the top element
	Card dealtCard = cards.front();

	// delete from hand
	cards.pop_front();

	// return the top element
	return dealtCard;
}

// add a card to the hand.
void Hand::addACard(Card newCard) {
	cards.push_back(newCard);
}

// calculate and return total points of the hand.
int Hand::getPoints() {
	int totalPoints = 0;

	// incrementally add values to totalPoints
	std::list<Card>::iterator it;
	for (it = cards.begin(); it != cards.end(); ++it) {
		totalPoints += it->value;
	}

	// if has an ace, and total points does not exceed 21 when ace is counted as 11, add 10 to total points.
	if (hasAnAce() && totalPoints + 10 <= 21) {
		totalPoints += 10;
	}

	return totalPoints;
}

// find if the hand has an ace.
bool Hand::hasAnAce() {
	// initialize hasAce.
	bool hasAce = false;

	std::list<Card>::iterator it;
	// iterate through the cards and set hasAce to true if an ace is found.
	for (it = cards.begin(); it != cards.end(); ++it) {
		if (it->value == 1) {
			hasAce = true;
			break;
		}
	}
	return hasAce;
}