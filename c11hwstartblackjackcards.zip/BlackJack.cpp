#include<iostream>
#include "Card.h"
#include "Hand.h"
#include "BlackJack.h"

//
// PLAY
//

// the method below has been written for you to help you understand how your methods will be used
void BlackJack::play() {
    std::cout << "Let's Play BlackJack!" << std::endl;

    bool gameOver = false; // Bust means >21
    this->printInstructions(); // print instructions
    this->printBoard(); // print the board

    while (!gameOver) { // keep playing as long as the game is not won by either player

        gameOver = this->takePlayerTurn(); // current player takes a turn

        if (gameOver) {
            break;
        }

        this->printBoard(); // print the board if that was a good move


        gameOver = this->takeDealerTurn(); // AI takes a turn

        if (gameOver)
            break;

    } // end while: game over

    // note below that the winning player is who we want, not the current player
    if (getWinningPlayerId() != -1)
        std::cout << "Congratulations: " << playerNames[getWinningPlayerId()] << " has won the game!" << std::endl;
    else
        std::cout << "Looks like the game was a tie" << std::endl;

    std::cout << "Goodbye!" << std::endl;

} // end play()

// constructor.
BlackJack::BlackJack(std::vector<std::string> _playerNames, std::vector<int> cardID) {
    int nofInitialCards = cardID.size();

    // iterate through initial cards and push back into cards.
    for (int i = 0; i < nofInitialCards; i++) {
        deck.addACard(Card(cardID[i]));
    }

    // initialize winning player id as -1.
    winningPlayerId = -1;

    // set input player names.
    playerNames = _playerNames;
}

// print the instructions to the console.
void BlackJack::printInstructions() {
    // write the instructions.
    std::cout << "Try to get closest to 21 without going over" << std::endl;
}

// print hand to console.
void BlackJack::printBoard() {
    // print dealer's hand.
    std::cout << "Dealer's Hand: ";
    dealerHand.printMe();
    std::cout << std::endl;

    // print player's hand.
    std::cout << "Player's Hand: ";
    playerHand.printMe();
    std::cout << std::endl;
}

// get player input and play for player.
bool BlackJack::takePlayerTurn() {
    // char that will hold player choice character from the command prompt.
    char playerChoice;

    // it will loop until player exceeds 21 or player stands.
    while (true) {
        // take player choice.
        std::cout << "Player's Turn: Hit (h) or Stand (s)? ";
        std::cin >> playerChoice;

        // if player selects hit.
        if (playerChoice == 'h') {
            std::cout << "Player Hits..." << std::endl;

            // add a card to player from the deck.
            playerHand.addACard(deck.dealACard());
            this->printBoard();

            // if player exceeds 21, set winning player to dealer (1) and return true.
            if (playerHand.getPoints() > 21) {
                winningPlayerId = 1;
                return true;
            }
            // if player is exactly 21, set winning player to no winner (-1) and return false.
            else if (playerHand.getPoints() == 21) {
                winningPlayerId = -1;
                return false;
            }
        }
        // if player selects stand, set winning player to no winner (-1) and return false.
        else if (playerChoice == 's') {
            std::cout << "Player Stands..." << std::endl;
            winningPlayerId = -1;
            return false;
        }
        // warn the user if player input is wrong.
        else {
            std::cout << "Wrong input!!!" << std::endl;
            continue;
        }        
    }
    return true;
}

// play for dealer.
bool BlackJack::takeDealerTurn() {
    std::cout << "Dealer's Turn... ";

    // it will loop until dealer exceeds 16.
    while (true) {
        // if current dealer point is less than 16, dealer hits.
        if(dealerHand.getPoints() <= 16) {
            std::cout << "Dealer Hits..." << std::endl;

            // add a card to dealer from deck.
            dealerHand.addACard(deck.dealACard());
            this->printBoard();

            // if dealer exceeds 21, set winning player to player (0) and return true.
            if (dealerHand.getPoints() > 21) {
                winningPlayerId = 0;
                return true;
            }
        }

        // if current dealer point is greater than 16, dealer stands.
        else {
            std::cout << "Dealer Stands..." << std::endl;
            // if dealer point is >= player point, set winning player to dealer (1)
            if (dealerHand.getPoints() >= playerHand.getPoints()) {
                winningPlayerId = 1;
            }
            // otherwise set winning player to player (0)
            else {
                winningPlayerId = 0;
            }
            return true;
        }
    }
    return true;
}


// return winning player id.
int BlackJack::getWinningPlayerId() {
    return winningPlayerId;
}

// return player points.
int BlackJack::getPlayerPoints() {
    return playerHand.getPoints();
}

// return dealer points.
int BlackJack::getDealerPoints() {
    return dealerHand.getPoints();
}